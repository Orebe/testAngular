export class Drugs {
  name: string = null;
  posMorning = 0;
  posMidday = 0;
  posEvening = 0;
}
