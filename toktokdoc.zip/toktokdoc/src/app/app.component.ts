import {Component} from '@angular/core';
import {DrugService} from './DrugService';
import {Drugs} from './Drugs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  file: any;
  search: string = null;
  tabSearchDrugsName: string[] = [];
  tabDrugs: Drugs[] = [];
  showDrugsList: boolean = false;

  constructor(private drugService: DrugService) {
  }

  // Call DrugAPI and fill an array with drug name.
  searchDrugs() {
    if (!this.search) {
      alert('Aucun champ n\'est renseigné dans la recherche');
      return;
    }
    this.drugService.callDrugApi(this.search.toLowerCase()).subscribe((data) => {
      if (this.isEmptyArray(data)) {
        alert('La requête n\'a pas pu renvoyer de réponse');
        return;
      }
      this.search = null;
      this.tabSearchDrugsName = this.getTextKeyFromData(data);
      this.showDrugsList = true;
    });
  }

  // Map data to get only textKey property.
  getTextKeyFromData(data) {
    return data.map(key => key.textKey);
  }

  // Add new drug in drugsTab
  creatingNewDrugInTab(drug: string) {
    const drugs = new Drugs();
    drugs.name = drug;
    this.tabDrugs.push(drugs);
    this.tabSearchDrugsName = [];
    this.showDrugsList = false;
  }

  // Add drugs to tabDrugs from importedFile
  addDrugFromImportedFile(data) {
    for (const element of data) {
      const drugs = new Drugs();
      drugs.name = element.name;
      drugs.posMorning = element.posMorning;
      drugs.posMidday = element.posMidday;
      drugs.posEvening = element.posEvening;
      this.tabDrugs.push(drugs);
    }
  }

  deleteDrugInTab(index: number, name: string) {
    if (confirm('Êtes-vous sur de vouloir supprimer le médicament: ' + name)) {
      this.tabDrugs.splice(index, 1);
    }
  }

  // Check if it's an empty array
  isEmptyArray(arr) {
    return arr.length === 0;
  }

  // Export data to JsonFile
  exportToJsonFile() {
    if (this.isEmptyArray(this.tabDrugs)) {
      alert('Il n\'y a rien à exporter');
      return;
    }
    const dataStr = JSON.stringify(this.tabDrugs);
    const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
    const exportFileDefaultName = 'data.json';
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  }

  // Import Json file and push it to data
  importToJsonFile(event) {
    this.file = event.target.files[0];
    const fileReader = new FileReader();
    fileReader.readAsText(this.file, 'UTF-8');
    fileReader.onload = () => {
      if (typeof fileReader.result === 'string') {
        try {
          const data = JSON.parse(fileReader.result);
          this.addDrugFromImportedFile(data);
        } catch (error) {
          alert(error);
          return;
        }
      }
    };
    fileReader.onerror = (error) => {
      alert(error);
    };
  }
}
