import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DrugService {

  constructor(private httpClient: HttpClient) {
  }

  // Call DrugAPI with textField as parameter
  public callDrugApi(textField: string) {
    return this.httpClient.get('https://hds-staging.toktokdoc.com/BCBSearch/X/' + textField);
  }
}
